<?php
$TRANSLATIONS = array(
"Back" => "Retour",
"Close" => "Fermer",
"Home" => "Racine",
"Open" => "Ouvrir",
"Save" => "Enregistrer",
"Refresh" => "Rafraichir",
"Select Image" => "Choisir une Image",
"Browse and select an image" => "Parcourir et choisir une image",
"Keep Aspect Ratio" => "Maintenir les proportions",
"Hour Symbol" => "h",
"Select" => "Choisir"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
