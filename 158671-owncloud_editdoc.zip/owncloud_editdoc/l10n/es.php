<?php
$TRANSLATIONS = array(
"Back" => "Atrás",
"Close" => "Cerrar",
"Home" => "Inicio",
"Open" => "Abrir",
"Save" => "Guardar",
"Refresh" => "Actualizar",
"Select Image" => "Seleccionar imagen",
"Browse and select an image" => "Explorar y seleccionar una imagen",
"Keep Aspect Ratio" => "Mantener relación de aspecto",
"Hour Symbol" => "h",
"Select" => "Seleccionar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
