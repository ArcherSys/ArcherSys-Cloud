<?php
$TRANSLATIONS = array(
"Back" => "Zurück",
"Close" => "Schließen",
"Home" => "Zurück zum Anfang",
"Open" => "Offen",
"Save" => "Speichern",
"Refresh" => "Erfrischen",
"Select Image" => "Bild Selektieren",
"Browse and select an image" => "Ein Bild suchen und selektieren",
"Keep Aspect Ratio" => "Seitenverhältnis beibehalten",
"Hour Symbol" => "u",
"Select" => "Selektieren"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

