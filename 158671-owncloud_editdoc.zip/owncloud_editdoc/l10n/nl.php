<?php
$TRANSLATIONS = array(
"Back" => "Terug",
"Close" => "Afsluiten",
"Home" => "Terug naar begin",
"Open" => "Open",
"Save" => "Bewaren",
"Refresh" => "Vernieuwen",
"Select Image" => "Selecteer Afbeelding",
"Browse and select an image" => "Blader en selecteer een afbeelding",
"Keep Aspect Ratio" => "Verhouding Behouden",
"Hour Symbol" => "u",
"Select" => "Selecteer"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
