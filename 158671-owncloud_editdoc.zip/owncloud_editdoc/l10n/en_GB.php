<?php
$TRANSLATIONS = array(
"Back" => "Back",
"Close" => "Close",
"Home" => "Home",
"Open" => "Open",
"Save" => "Save",
"Refresh" => "Refresh",
"Select Image" => "Select Image",
"Browse and select an image" => "Browse and select an image",
"Keep Aspect Ratio" => "Keep Aspect Ratio",
"Hour Symbol" => "h",
"Select" => "Select"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
