EditDoc is a WYSIWYG Editor plugin for ownCloud 7.x. 
EditDoc is based on TinyMCE (GNU LESSER GENERAL PUBLIC LICENSE).

Install:
- Download and extract the EditDoc files in folder '<%owncloud_webroot%>/apps/editdoc/'.
- Enable the ownCloud app in the ownCloud web admin section
- Disable CSP in owncloud config.php (read Known Issue nr2 in CHANGELOG.txt)
- Create Text file with extension .html. 
- Drop and Drag pictures into EditDoc. 
- To disable the imagePlugin edit index.php and set '$imagePlugin=false;'


Check the lastest version on: http://www.toolstogether.nl

Cheers Erwin

