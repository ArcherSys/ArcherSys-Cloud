<?php
OCP\Util::addScript('editdoc', 'editdoc');

